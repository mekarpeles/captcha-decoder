import sys, os

print os.listdir('./examples/')